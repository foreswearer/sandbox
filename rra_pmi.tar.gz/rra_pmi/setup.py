
from setuptools import setup, find_packages


setup(
    name='rra_pmi',
    version='1.0.0',
    author='Ramiro Rego',
    author_email='ramiro.rego@es.ibm.com',
    url='https://www.ibm.com/',
    description='Test package',
    packages=find_packages() + find_packages('.', include=['rra_pmi*']),
    package_dir = {
        'rra_pmi': 'rra_pmi'
    }
)