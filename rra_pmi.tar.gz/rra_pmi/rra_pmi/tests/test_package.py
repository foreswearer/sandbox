import pandas as pd

from rra_pmi import RRSquareField
from rra_pmi import RRCustomAnomaly
from sklearn.pipeline import Pipeline

df = pd.read_csv('machine_survival.csv')

X = df[['p_episode', 't_episode', 'f_episode', 'c_episode']]
y = df.has_failed

stages = [('square_transform', RRSquareField('f_episode')),
          ('custom_anomaly', RRCustomAnomaly())]

pipeline = Pipeline(stages, verbose=True)

pipeline.fit(X=X, y=y)
y_hat = pipeline.predict(X)
print(y_hat[0])
