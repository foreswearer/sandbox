import numpy as np

from sklearn.base import BaseEstimator, OutlierMixin
from sklearn.utils.validation import check_array, check_is_fitted


class RRCustomAnomaly(BaseEstimator):

    def __init__(self, demo_param='demo'):
        self.demo_param = demo_param

    def fit(self, X, y=None):
        self.X_ = X
        self.y_ = y
        self.prediction_ = np.random.randint(2, size=y.size)
        # Return the anomaly detector
        return self

    def predict(self, X):
        # Check is fit had been called
        check_is_fitted(self)

        # Input validation
        X = check_array(X)
        return self.prediction_
