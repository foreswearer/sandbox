from sklearn.base import BaseEstimator, TransformerMixin

__all__ = [
    'ramiro-rego/rra_pmi'
]


class RRSquareField(BaseEstimator, TransformerMixin):

    def __init__(self, var_squared):
        self._var_squared = var_squared

    def fit(self, x, y):
        return self

    def transform(self, x, y=None):
        var = self._var_squared
        _x = x.copy()  # to prevent SettingWithCopyWarning
        _x[var + '_2'] = (_x[var] ** 2)
        return _x
