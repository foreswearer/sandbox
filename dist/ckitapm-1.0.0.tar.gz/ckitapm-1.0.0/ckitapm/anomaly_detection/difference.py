# python setup.py build
# python setup.py sdist --formats=zip

import warnings

import numpy as np

from scipy.stats import mode
from scipy.stats import pearsonr

from sklearn.base import BaseEstimator
from sklearn.utils.validation import check_is_fitted


class CustomAnomalyDifference(BaseEstimator):

    def __init__(self):
        self.x_ = None
        self.y_ = None

        self.pearsonr_ = 1
        self.diff_ = 0
        self.p_mean_ = 0
        self.p_tmean_ = 0
        self.threshold_ = 0

    def fit(self, predictors, target=None):
        if target is not None:
            warnings.warn("target parameter passed but this model only trains on predictors")

        self.x_ = predictors

        self.pearsonr_ = pearsonr(predictors[:, 0], predictors[:, 1])[0]

        diff = np.abs(np.subtract(predictors[:, 0], predictors[:, 1]))
        diff_p = diff * self.pearsonr_

        p_mode = mode(diff_p, axis=None)[0]
        self.threshold_ = np.std(diff_p) + p_mode

        # Return the anomaly_detection detector
        return self

    def predict_proba(self, x):
        # Check if fit had been called
        check_is_fitted(self)

        diff = np.abs(np.subtract(x[:, 0], x[:, 1]))
        diff_p = diff * self.pearsonr_

        return diff_p

    def predict(self, x):
        # Check if fit had been called
        check_is_fitted(self)

        diff = np.abs(np.subtract(x[:, 0], x[:, 1]))
        diff_p = diff * self.pearsonr_

        return diff_p > self.threshold_
