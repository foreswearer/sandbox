import sys
from setuptools import setup

if sys.version_info < (3, 7):
    sys.exit('Python < 3.7 is not supported')

setup(
    name='ckitapm',
    version='1.0.0',
    packages=['ckitapm', 'ckitapm.anomaly_detection'],
    url='',
    license='',
    author='Ramiro Rego Alvarez',
    author_email='ramiro.rego@es.ibm.com',
    description='Package with custom algorithms'
)
