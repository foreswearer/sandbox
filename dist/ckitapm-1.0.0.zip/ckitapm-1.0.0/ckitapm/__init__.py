__version__ = '1.0.0.rc01'

from ckitapm.anomaly_detection.difference import CustomAnomalyDifference
